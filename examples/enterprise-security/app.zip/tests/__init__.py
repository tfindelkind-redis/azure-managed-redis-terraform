"""
Test modules
"""
from .redis_tests import redis_test_suite, RedisTestSuite

__all__ = ['redis_test_suite', 'RedisTestSuite']
